const t="form",s=o=>o.category===t,a=o=>o.category!==t;export{t as F,a,s as i};
