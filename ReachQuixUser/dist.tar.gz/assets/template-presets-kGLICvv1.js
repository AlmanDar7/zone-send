const f=["brand","eyebrow","hero","headline","subheadline","body","cta","secondary","footer"],u={brand:{label:"Brand badge",hint:"Top label, e.g. your company name"},eyebrow:{label:"Eyebrow",hint:"Small label above the headline"},hero:{label:"Hero image",hint:"Main image URL"},headline:{label:"Headline",hint:"Primary title"},subheadline:{label:"Subheadline",hint:"Supporting line under the title"},body:{label:"Main copy",hint:"Email body text"},cta:{label:"Button",hint:"Call-to-action label and link"},form:{label:"Form",hint:"Opt-in form inputs"},secondary:{label:"Extra section",hint:"Bonus box title and text"},footer:{label:"Footer",hint:"Legal or unsubscribe note"},style:{label:"Colors",hint:"Accent and background colors"}},A=["brand","eyebrow","hero","headline","subheadline","body","cta","form","secondary","footer"],z={brand:"Brand",eyebrow:"Label",hero:"Image",headline:"Heading",subheadline:"Subheading",body:"Text",cta:"Button",form:"Form",secondary:"Info box",footer:"Footer",style:"Colors"},F=(e,o)=>{const r=c(e);return o==="style"||r.includes(o)?r:[...r,o]},I=(e,o)=>c(e).filter(r=>r!==o),c=e=>{const o=e!=null&&e.length?[...e]:[...f],r=new Set,i=[];for(const a of o)!r.has(a)&&u[a]&&(r.add(a),i.push(a));for(const a of f)r.has(a)||i.push(a);return i.filter(a=>a!=="style")},d=e=>(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"),l=e=>d(e).replace(/\n/g,"<br>"),y=e=>{const o=c(e.sectionOrder),r={brand:`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="display:inline-block;border:1px solid #d1d5db;border-radius:999px;padding:10px 18px;font-size:12px;letter-spacing:0.22em;text-transform:uppercase;color:#374151;">
          ${l(e.brandName)}
        </div>
      </div>`,eyebrow:`
        <div style="font-family:Arial,sans-serif;font-size:11px;letter-spacing:0.18em;text-transform:uppercase;color:#6b7280;text-align:center;margin-bottom:14px;">
          ${l(e.eyebrow)}
        </div>`,hero:`
        <img src="${d(e.heroImageUrl)}" alt="Template hero" style="width:100%;height:220px;object-fit:cover;border-radius:18px;margin-bottom:20px;" />`,headline:`
        <h1 style="font-size:38px;line-height:1.1;margin:0 0 14px;color:#111827;font-weight:500;text-align:center;">
          ${l(e.headline)}
        </h1>`,subheadline:`
        <p style="font-family:Arial,sans-serif;font-size:15px;line-height:1.7;color:#4b5563;margin:0 0 18px;text-align:center;">
          ${l(e.subheadline)}
        </p>`,body:`
        <div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.8;color:#374151;margin-bottom:20px;text-align:center;">
          ${l(e.body)}
        </div>`,cta:`
        <div style="text-align:center;margin-bottom:22px;">
          <a href="${d(e.ctaUrl)}" style="display:inline-block;background:${e.accentColor};color:#1f2937;text-decoration:none;padding:14px 28px;border-radius:999px;font-family:Arial,sans-serif;font-size:13px;font-weight:600;letter-spacing:0.06em;text-transform:uppercase;">
            ${l(e.ctaText)}
          </a>
        </div>`,form:`
        <form style="margin-bottom:22px;text-align:left;">
          ${e.formShowNameField?`<div style="margin-bottom:12px;">
                  <input type="text" placeholder="${d(e.formNamePlaceholder)}" style="width:100%;padding:14px 16px;border:1px solid #d1d5db;border-radius:12px;font-family:Arial,sans-serif;font-size:15px;box-sizing:border-box;" required />
                </div>`:""}
          <div style="margin-bottom:16px;">
            <input type="email" placeholder="${d(e.formEmailPlaceholder)}" style="width:100%;padding:14px 16px;border:1px solid #d1d5db;border-radius:12px;font-family:Arial,sans-serif;font-size:15px;box-sizing:border-box;" required />
          </div>
          <button type="submit" style="width:100%;background:${e.accentColor};color:#1f2937;border:none;padding:16px;border-radius:12px;font-family:Arial,sans-serif;font-size:15px;font-weight:700;cursor:pointer;">
            ${l(e.formSubmitLabel)}
          </button>
        </form>`,secondary:`
        <div style="background:#f9fafb;border-radius:18px;padding:18px 20px;">
          <div style="font-family:Arial,sans-serif;font-size:12px;letter-spacing:0.14em;text-transform:uppercase;color:#6b7280;margin-bottom:10px;">
            ${l(e.secondaryTitle)}
          </div>
          <div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.7;color:#4b5563;">
            ${l(e.secondaryBody)}
          </div>
        </div>`,footer:`
      <p style="font-family:Arial,sans-serif;font-size:12px;line-height:1.7;color:#6b7280;text-align:center;margin:20px 12px 0;">
        ${l(e.footerNote)}
      </p>`,style:""},i=new Set(["eyebrow","hero","headline","subheadline","body","cta","form","secondary"]),a=[],p=[],m=[];for(const n of o)n!=="style"&&(n==="brand"?a.push(r.brand):n==="footer"?m.push(r.footer):i.has(n)&&p.push(r[n]));const h=p.length>0?`<div style="background:white;border-radius:28px;padding:24px;border:1px solid #e5e7eb;box-shadow:0 18px 40px rgba(15,23,42,0.08);">${p.join("")}</div>`:"";return`
    <div style="max-width:620px;margin:0 auto;background:${e.backgroundColor};padding:28px 24px;font-family:Georgia, 'Times New Roman', serif;color:#1f2937;">
      ${a.join("")}
      ${h}
      ${m.join("")}
    </div>
  `},x={FirstName:"Ava",Email:"ava@northstar.co",CompanyName:"Northstar"},g=(e,o)=>{if(!e)return"";const r={...x,...o};return e.replace(/\{\{(\w+)\}\}/g,(i,a)=>r[a]||`{{${a}}}`)},s=e=>(e||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;"),t=e=>g(s(e)).replace(/\n/g,"<br>"),w=()=>({presetId:"lead-magnet",brandName:"Ava Studio",eyebrow:"Free Guide",headline:"Your [Enter Title of Lead Magnet] Is Here!",subheadline:"Share a polished lead magnet that feels premium, on-brand, and easy to scan.",body:`Welcome {{FirstName}},

I am excited to share this free resource with you. This guide walks you through key steps, quick wins, and practical ideas you can use right away at {{CompanyName}}.`,ctaText:"Download The Guide",ctaUrl:"https://example.com/guide",heroImageUrl:"https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=900&q=80",secondaryTitle:"What is inside",secondaryBody:"Use this section to highlight 2 or 3 key takeaways, action steps, or bonuses the reader will get after clicking.",footerNote:"You are receiving this because you requested resources from Ava Studio.",accentColor:"#c7d8cf",backgroundColor:"#f8f6f2",formShowNameField:!0,formNamePlaceholder:"First Name",formEmailPlaceholder:"Email Address",formSubmitLabel:"Subscribe"}),v=()=>({presetId:"product-showcase",brandName:"Northstar Labs",eyebrow:"New Arrival",headline:"Launch your next favorite product with a polished reveal",subheadline:"Use a strong hero section, supporting copy, and a clear CTA to drive clicks.",body:`Hi {{FirstName}},

We built this layout for teams that want product emails to feel elevated instead of plain. Add your main announcement, social proof, or offer details here.`,ctaText:"Shop Now",ctaUrl:"https://example.com/product",heroImageUrl:"https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=900&q=80",secondaryTitle:"Why readers click",secondaryBody:"Pair your strongest product image with short benefit-led copy, then finish with a high-contrast button.",footerNote:"Questions? Reply to this email and our team will help.",accentColor:"#d7c7bb",backgroundColor:"#f6f0ea",formShowNameField:!0,formNamePlaceholder:"First Name",formEmailPlaceholder:"Email Address",formSubmitLabel:"Subscribe"}),N=()=>({presetId:"newsletter-digest",brandName:"Weekly Brief",eyebrow:"Newsletter",headline:"A cleaner way to share updates, stories, and useful links",subheadline:"Ideal for weekly digests, founder updates, and curated content roundups.",body:`Hello {{FirstName}},

Here is your latest update. Add a short editor's note, summary paragraph, or featured story introduction here before the CTA.`,ctaText:"Read The Full Update",ctaUrl:"https://example.com/newsletter",heroImageUrl:"https://images.unsplash.com/photo-1519389950473-47ba0277781c?auto=format&fit=crop&w=900&q=80",secondaryTitle:"This edition includes",secondaryBody:"Add featured articles, campaign highlights, product milestones, or upcoming events in this supporting section.",footerNote:"You are subscribed to Weekly Brief. Update your preferences anytime.",accentColor:"#bfd4d9",backgroundColor:"#f4f8f9",formShowNameField:!1,formNamePlaceholder:"First Name",formEmailPlaceholder:"Email Address",formSubmitLabel:"Subscribe"}),$=()=>({presetId:"popup-form",brandName:"Join Us",eyebrow:"Newsletter",headline:"Get 15% off your first order",subheadline:"Join our mailing list to receive exclusive offers and updates.",body:"",ctaText:"Close",ctaUrl:"#",heroImageUrl:"https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=900&q=80",secondaryTitle:"",secondaryBody:"",footerNote:"We respect your privacy.",accentColor:"#111827",backgroundColor:"#ffffff",sectionOrder:["hero","headline","subheadline","form","footer"],formShowNameField:!0,formNamePlaceholder:"First Name",formEmailPlaceholder:"Email Address",formSubmitLabel:"Subscribe Now"}),T=()=>({presetId:"inline-form",brandName:"Stay Updated",eyebrow:"Updates",headline:"Subscribe to our newsletter",subheadline:"Get the latest news delivered directly to your inbox.",body:"",ctaText:"Close",ctaUrl:"#",heroImageUrl:"https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=900&q=80",secondaryTitle:"",secondaryBody:"",footerNote:"No spam, ever.",accentColor:"#3b82f6",backgroundColor:"#f8fafc",sectionOrder:["eyebrow","headline","subheadline","form","footer"],formShowNameField:!1,formNamePlaceholder:"First Name",formEmailPlaceholder:"Email Address",formSubmitLabel:"Join Now"}),k=()=>({presetId:"full-page-form",brandName:"Waitlist",eyebrow:"Early Access",headline:"Join the Waitlist",subheadline:"Be the first to know when we launch our new platform.",body:"Our new platform is launching soon. Join the waitlist to secure your spot and get exclusive early access benefits.",ctaText:"Close",ctaUrl:"#",heroImageUrl:"https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=900&q=80",secondaryTitle:"Why join?",secondaryBody:"Early adopters get 50% off their first year, plus a free onboarding session with our team.",footerNote:"By joining, you agree to our terms of service.",accentColor:"#059669",backgroundColor:"#f0fdf4",sectionOrder:["brand","hero","headline","subheadline","form","secondary","footer"],formShowNameField:!0,formNamePlaceholder:"Your Name",formEmailPlaceholder:"Your best email",formSubmitLabel:"Join the Waitlist"}),b=[{id:"lead-magnet",name:"Lead Magnet Download",description:"A minimal, editorial-style email for guides, freebies, and welcome downloads.",category:"email",defaultSubject:"{{FirstName}}, your free guide is ready",defaultType:"Initial",createConfig:w},{id:"product-showcase",name:"Product Showcase",description:"A more promotional visual layout for launches, collections, and featured offers.",category:"email",defaultSubject:"{{FirstName}}, take a look at our latest release",defaultType:"Initial",createConfig:v},{id:"newsletter-digest",name:"Newsletter Digest",description:"A polished update template for weekly roundups, stories, and curated content.",category:"email",defaultSubject:"{{FirstName}}, here is this week's update",defaultType:"Follow-up 1",createConfig:N},{id:"popup-form",name:"Popup Form",description:"A high-converting popup form with an image and offer.",category:"form",defaultSubject:"",defaultType:"Initial",createConfig:$},{id:"inline-form",name:"Inline Form",description:"A clean, horizontal form designed to be embedded within articles or blog posts.",category:"form",defaultSubject:"",defaultType:"Initial",createConfig:T},{id:"full-page-form",name:"Full Page Form",description:"A standalone landing page form perfect for link-in-bio or dedicated campaigns.",category:"form",defaultSubject:"",defaultType:"Initial",createConfig:k}],S=e=>b.find(o=>o.id===e)??b[0],C=e=>{const o=[e.headline,"",e.subheadline,"",e.body,"",`${e.secondaryTitle}`,e.secondaryBody,"",`${e.ctaText}: ${e.ctaUrl}`,"",e.footerNote].join(`
`);`${e.backgroundColor}${t(e.brandName)}${t(e.eyebrow)}${s(e.heroImageUrl)}${t(e.headline)}${t(e.subheadline)}${t(e.body)}${s(e.ctaUrl)}${e.accentColor}${t(e.ctaText)}${t(e.secondaryTitle)}${t(e.secondaryBody)}${t(e.footerNote)}`;const r=`
    <div style="max-width:640px;margin:0 auto;background:${e.backgroundColor};padding:18px;font-family:Arial,sans-serif;color:#1f2937;">
      <div style="background:white;border-radius:28px;padding:24px;border:1px solid #ebe7e3;box-shadow:0 16px 36px rgba(15,23,42,0.08);">
        <div style="font-size:12px;letter-spacing:0.18em;text-transform:uppercase;color:#8b5e3c;margin-bottom:10px;">
          ${t(e.eyebrow)}
        </div>
        <h1 style="font-family:Georgia, 'Times New Roman', serif;font-size:34px;line-height:1.15;color:#111827;margin:0 0 18px;">
          ${t(e.headline)}
        </h1>
        <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="margin-bottom:18px;">
          <tr>
            <td width="52%" valign="top" style="padding-right:10px;">
              <img src="${s(e.heroImageUrl)}" alt="Template hero" style="width:100%;height:260px;object-fit:cover;border-radius:22px;display:block;" />
            </td>
            <td width="48%" valign="top" style="padding-left:10px;">
              <p style="font-size:15px;line-height:1.7;color:#6b7280;margin:0 0 14px;">
                ${t(e.subheadline)}
              </p>
              <div style="font-size:14px;line-height:1.8;color:#374151;margin-bottom:14px;">
                ${t(e.body)}
              </div>
              <div style="background:#f8fafc;border-radius:18px;padding:16px;">
                <div style="font-size:12px;letter-spacing:0.14em;text-transform:uppercase;color:#64748b;margin-bottom:8px;">
                  ${t(e.secondaryTitle)}
                </div>
                <div style="font-size:14px;line-height:1.7;color:#475569;">
                  ${t(e.secondaryBody)}
                </div>
              </div>
            </td>
          </tr>
        </table>
        <a href="${s(e.ctaUrl)}" style="display:inline-block;background:#111827;color:white;text-decoration:none;padding:14px 24px;border-radius:999px;font-size:13px;font-weight:600;">
          ${t(e.ctaText)}
        </a>
      </div>
      <p style="font-size:12px;line-height:1.7;color:#6b7280;text-align:center;margin:18px 8px 0;">
        ${t(e.footerNote)}
      </p>
    </div>
  `,i=`
    <div style="max-width:640px;margin:0 auto;background:${e.backgroundColor};padding:22px;font-family:Arial,sans-serif;color:#1f2937;">
      <div style="background:white;border-radius:26px;padding:28px;border:1px solid #e2e8f0;box-shadow:0 16px 34px rgba(15,23,42,0.07);">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;gap:12px;">
          <div style="font-size:20px;font-weight:700;color:#0f172a;">${t(e.brandName)}</div>
          <div style="font-size:11px;letter-spacing:0.16em;text-transform:uppercase;color:#64748b;">${t(e.eyebrow)}</div>
        </div>
        <img src="${s(e.heroImageUrl)}" alt="Template hero" style="width:100%;height:220px;object-fit:cover;border-radius:20px;display:block;margin-bottom:18px;" />
        <h1 style="font-size:32px;line-height:1.2;color:#0f172a;margin:0 0 12px;font-family:Georgia, 'Times New Roman', serif;">
          ${t(e.headline)}
        </h1>
        <p style="font-size:15px;line-height:1.8;color:#475569;margin:0 0 16px;">
          ${t(e.subheadline)}
        </p>
        <div style="font-size:14px;line-height:1.85;color:#334155;margin-bottom:18px;">
          ${t(e.body)}
        </div>
        <div style="border:1px solid #e2e8f0;border-radius:18px;padding:18px;margin-bottom:18px;background:#f8fafc;">
          <div style="font-size:12px;letter-spacing:0.16em;text-transform:uppercase;color:#64748b;margin-bottom:10px;">
            ${t(e.secondaryTitle)}
          </div>
          <div style="font-size:14px;line-height:1.8;color:#475569;">
            ${t(e.secondaryBody)}
          </div>
        </div>
        <a href="${s(e.ctaUrl)}" style="display:inline-block;background:${e.accentColor};color:#0f172a;text-decoration:none;padding:14px 24px;border-radius:14px;font-size:13px;font-weight:700;">
          ${t(e.ctaText)}
        </a>
      </div>
      <p style="font-size:12px;line-height:1.7;color:#64748b;text-align:center;margin:18px 8px 0;">
        ${t(e.footerNote)}
      </p>
    </div>
  `,a=e.presetId==="product-showcase"?r:e.presetId==="newsletter-digest"?i:y(e);return{body:o,htmlBody:a}},U=e=>{const o=S(e),r=o.createConfig(),i=C(r);return{name:o.name,subject:o.defaultSubject,body:i.body,type:o.defaultType,template_format:"visual",html_body:i.htmlBody,design_config:r}};export{f as D,A as V,C as a,y as b,u as c,z as d,F as e,I as f,U as g,c as n,g as r,x as s,b as v};
